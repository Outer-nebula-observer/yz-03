# -*- coding: utf-8 -*-
"""
memsys.long_term.factual_store — 事实记忆库（SQLite）
=====================================================
思路来源：ChatDB（笔记_Hu2023-ChatDB）——"数据库当符号记忆"。
  - 事实 = 结构化行：content(原文) + attr/value 键值对（装备参数、条令条款…）；
  - 精确查询：属性键值过滤（MVP 内置 mini 过滤器，后续可升级 NL→SQL）；
  - 辅助语义检索：向量索引做近似召回（参数名记不清时兜底）。

存储：单文件 SQLite（stdlib sqlite3，零依赖）。表结构：
    facts(id TEXT PK, type TEXT, content TEXT, source TEXT, session_id TEXT,
          timestamp REAL, importance REAL, decay_strength REAL,
          recall_count INTEGER, last_recalled_at REAL,
          attrs_json TEXT, merged_from_json TEXT, op_history_json TEXT)
"""

from __future__ import annotations

import json
import sqlite3
import threading
from typing import List, Optional

from ..schema import MemoryEntry, MemoryType, RetrievedMemory, new_entry
from ..embeddings import MemoryVectorIndex, MockEmbedding
from .base import BaseLongTermStore

_SCHEMA = """
CREATE TABLE IF NOT EXISTS facts (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    source TEXT DEFAULT '',
    session_id TEXT DEFAULT '',
    timestamp REAL,
    importance REAL DEFAULT 1.0,
    decay_strength REAL DEFAULT 1.0,
    recall_count INTEGER DEFAULT 0,
    last_recalled_at REAL,
    attrs_json TEXT DEFAULT '{}',
    merged_from_json TEXT DEFAULT '[]',
    op_history_json TEXT DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_facts_ts ON facts(timestamp);
"""


def _escape_like(query: str) -> str:
    """转义 LIKE 元字符（%/_/\\），配合 ESCAPE '\\\\' 子句做字面匹配。"""
    return (query.replace("\\", "\\\\").replace("%", "\\%")
            .replace("_", "\\_"))


class FactualStore(BaseLongTermStore):
    """事实记忆库：SQLite 行存 + 向量辅助索引。

    用法：
        store = FactualStore("facts.db")
        e = new_entry(MemoryType.FACT, "红方 T-90 主战坦克",
                      attrs={"单位": "红方", "装备": "T-90", "最大速度": "60km/h"})
        store.add(e)
        store.search("T-90 速度")             # 语义/关键词混合
        store.search_attrs({"装备": "T-90"})   # 精确属性过滤（参数级召回）
    """

    def __init__(self, db_path: str = ":memory:",
                 embedding: Optional[MockEmbedding] = None) -> None:
        # 【线程安全修复】webui 用 ThreadingHTTPServer（每请求一线程），
        # SQLite 默认禁止跨线程使用 → check_same_thread=False 放开限制，
        # 并用 RLock 串行化全部读写（SQLite 单连接本身非并发安全）。
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(_SCHEMA)
        self.vindex = MemoryVectorIndex(embedding or MockEmbedding())
        # 【Bug 修复·BM25 缓存失效】语料版本号：add/update/remove 时 +1，
        # hybrid 的 BM25 缓存据此重建（此前只看 size，内容原地更新/等量换血
        # 时索引陈旧——检索到已不存在的词法命中）。
        self.version = 0
        # 启动时把已有行登记进向量索引（幂等）
        with self._lock:
            for row in self.conn.execute("SELECT id, content FROM facts"):
                self.vindex.add(row["id"], row["content"])

    # ------------------------- 行 <-> 条目 转换 -------------------------
    @staticmethod
    def _row_to_entry(row: sqlite3.Row) -> MemoryEntry:
        return MemoryEntry(
            id=row["id"], type=MemoryType.FACT, content=row["content"],
            source=row["source"], session_id=row["session_id"],
            timestamp=row["timestamp"], importance=row["importance"],
            decay_strength=row["decay_strength"], recall_count=row["recall_count"],
            last_recalled_at=row["last_recalled_at"],
            metadata=json.loads(row["attrs_json"]),
            merged_from=json.loads(row["merged_from_json"]),
            op_history=json.loads(row["op_history_json"]),
        )

    @staticmethod
    def _entry_params(e: MemoryEntry) -> tuple:
        return (e.id, e.content, e.source, e.session_id, e.timestamp, e.importance,
                e.decay_strength, e.recall_count, e.last_recalled_at,
                json.dumps(e.metadata, ensure_ascii=False),
                json.dumps(e.merged_from), json.dumps(e.op_history))

    # ------------------------- 写路径（进化层专用） -------------------------
    def add(self, entry: MemoryEntry) -> MemoryEntry:
        with self._lock:
            self.conn.execute(
                "INSERT OR REPLACE INTO facts VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                self._entry_params(entry))
            self.conn.commit()
        self.vindex.add(entry.id, entry.content)
        self.version += 1  # 语料变了 → BM25 缓存需重建
        return entry

    def persist_recall(self, entry: MemoryEntry) -> None:
        """把'命中强化'（recall_count/decay_strength/last_recalled_at）回写 SQLite。

        【Bug 修复】此前 search() 里 e.mark_recalled() 只改了临时对象
        （_row_to_entry 每次新建），重启即失、retention() 永远按原始时间衰减
        → 高频使用的事实也会被 forget() 误删。此方法由 hybrid 融合排序后
        统一调用（见 hybrid.py 第 4 步），保证强化真实落库。
        """
        with self._lock:
            self.conn.execute(
                "UPDATE facts SET recall_count=?, decay_strength=?, last_recalled_at=? "
                "WHERE id=?",
                (entry.recall_count, entry.decay_strength,
                 entry.last_recalled_at, entry.id))
            self.conn.commit()

    def update(self, entry: MemoryEntry) -> None:
        self.add(entry)  # INSERT OR REPLACE 幂等

    def remove(self, entry_id: str) -> None:
        with self._lock:
            self.conn.execute("DELETE FROM facts WHERE id=?", (entry_id,))
            self.conn.commit()
        self.vindex.remove(entry_id)
        self.version += 1  # 语料变了 → BM25 缓存需重建

    # ------------------------- 读路径（检索层） -------------------------
    def get(self, entry_id: str) -> Optional[MemoryEntry]:
        with self._lock:
            row = self.conn.execute("SELECT * FROM facts WHERE id=?",
                                    (entry_id,)).fetchone()
        return self._row_to_entry(row) if row else None

    def candidates(self) -> List[str]:
        with self._lock:
            return [r["id"] for r in self.conn.execute("SELECT id FROM facts")]

    def search(self, query: str, top_k: int = 5) -> List[RetrievedMemory]:
        """混合检索：向量相似（主）+ 内容关键词包含（兜底）。

        【Bug 修复】此处不再调 mark_recalled()——强化副作用统一移到
        hybrid.retrieve() 融合排序后执行（否则三路互检会让同一记忆
        recall_count 虚涨 3 倍、艾宾浩斯模型失真）。纯只读检索。
        """
        results: List[RetrievedMemory] = []
        # 1) 向量近似召回
        for mid, score in self.vindex.search(query, top_k=top_k):
            e = self.get(mid)
            if e:
                results.append(RetrievedMemory(entry=e, score=score, route="vector"))
        # 2) 关键词直查兜底（低级但精确——参数名直给时最稳）
        # 【Bug 修复·LIKE 通配符】查询里的 %/_/\\ 原是 SQL LIKE 元字符
        # （"fact-____" 会命中 "fact-1234"），先转义再拼 %…%。
        with self._lock:
            rows = self.conn.execute(
                "SELECT * FROM facts WHERE content LIKE ? ESCAPE '\\'",
                (f"%{_escape_like(query)}%",)).fetchall()
        for row in rows:
            e = self._row_to_entry(row)
            if not any(r.entry.id == e.id for r in results):
                results.append(RetrievedMemory(entry=e, score=1.0, route="sql"))
        results.sort(key=lambda r: r.score, reverse=True)
        for i, r in enumerate(results[:top_k]):
            r.rank = i + 1
        return results[:top_k]

    def search_attrs(self, attrs: dict, top_k: int = 5) -> List[RetrievedMemory]:
        """属性精确过滤（参数级召回——ChatDB 符号查询的 MVP 形态）。

        NL→SQL 的落地路径：LLM 把"红方 T-90 多快"解析为 attrs 过滤条件，
        再调本方法（后续接真模型时在 retrieval 层做意图解析）。
        同 search()：纯只读，强化在 hybrid 层统一做。
        """
        hits: List[RetrievedMemory] = []
        with self._lock:
            all_rows = self.conn.execute("SELECT * FROM facts").fetchall()
        for row in all_rows:
            e = self._row_to_entry(row)
            if all(e.metadata.get(k) == v for k, v in attrs.items()):
                hits.append(RetrievedMemory(entry=e, score=1.0, route="sql"))
        return hits[:top_k]

    def search_vector(self, query: str, top_k: int = 5) -> List[RetrievedMemory]:
        """纯向量检索（hybrid 的 vector 路专用）。

        【评审修复】此前 vector 路复用 search()（向量 + LIKE 兜底混合），
        导致"vector 单路"混入符号命中、且同一条目以 route=sql 标签重复
        计分。本方法只走向量索引——保证单路消融（G5）的口径纯净。
        """
        results: List[RetrievedMemory] = []
        for mid, score in self.vindex.search(query, top_k=top_k):
            e = self.get(mid)
            if e:
                results.append(RetrievedMemory(entry=e, score=score,
                                               route="vector"))
        return results[:top_k]

    def close(self) -> None:
        """关闭 SQLite 连接，释放文件句柄（Windows 删除 db 前必须调用）。"""
        with self._lock:
            try:
                self.conn.close()
            except Exception:
                pass

    def search_content_like(self, query: str, top_k: int = 5) -> List[RetrievedMemory]:
        """纯词法包含匹配（hybrid 的 sql 路专用）：content LIKE %query%。

        【Bug 修复·sql 路污染】此前 sql 路复用 search()（向量+LIKE 混合），
        导致：① 零相似度的向量命中混进符号路（cos=0 也返回）；
        ② 同一条目在 vector 路被重复计分（融合分虚高、min_score 失效）。
        本方法只做 LIKE（通配符已转义），保证 sql 路是纯符号路径。
        """
        hits: List[RetrievedMemory] = []
        with self._lock:
            rows = self.conn.execute(
                "SELECT * FROM facts WHERE content LIKE ? ESCAPE '\\'",
                (f"%{_escape_like(query)}%",)).fetchall()
        for row in rows[:top_k]:
            hits.append(RetrievedMemory(entry=self._row_to_entry(row),
                                        score=1.0, route="sql"))
        return hits
